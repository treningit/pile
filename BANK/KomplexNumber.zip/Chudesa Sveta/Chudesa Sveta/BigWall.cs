﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace China
{
    class BigWall
    {
       public static void Print()
        {
            Console.WriteLine("Tiguani");
        }
    }
}
