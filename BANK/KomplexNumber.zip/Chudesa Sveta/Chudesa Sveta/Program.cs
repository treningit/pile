﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using China;
using Ukatan;
using Egypt;
using Rio;
using India;
using Iordania;
using Peru;
using Italia;


namespace Chudesa_Sveta
{
    class Program
    {
        static void Main(string[] args)
        {
            Piramida.Print();
            ChihenIca.Print();
            BOG.Print();
            TadgMahal.Print();
            Petra.Print();
            MachuPikchu.Print();
            BigWall.Print();
            Kolizei.Print();
        }
    }
}
