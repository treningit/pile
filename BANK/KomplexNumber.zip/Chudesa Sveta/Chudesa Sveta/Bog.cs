﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rio
{
    class BOG
    {
        public static void Print()
        {
            Console.WriteLine("Karnaval");
        }
    }
}
