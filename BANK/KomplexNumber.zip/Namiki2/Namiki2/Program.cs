﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using a;

namespace a
{
    class b
    {
        public void Met()
    {
       //a obj = new a();
        Console.WriteLine("!!!!!!!");
    }
    }
}

namespace Namiki2
{
    //class a { }
    class Program
    {
        static void Main(string[] args)
        {
            ClassA asd = new ClassA();
            b asdf = new b();
            asd.Met();
            asdf.Met();
            
            
        }
    }
}
