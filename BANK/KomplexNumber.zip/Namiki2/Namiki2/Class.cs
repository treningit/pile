﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//smotri suda
using Namiki2;
 namespace a
{
    class ClassA
    {
        public void Met()
    {
       //a obj = new a();
        Console.WriteLine("dfgdfg");
    }

    }
}
