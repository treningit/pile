﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Humm
{
    class Employee:Humman
    {
        public Employee():base()
        {

        }
        public Employee(string N,DateTime B):base(N,B)
        {

        }
        public Employee(string N):base(N)
        {

        }
        public new void Work()
        {
            base.Work();
        }
    }
}
