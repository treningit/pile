﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ukraine
{
    class Kiyv
    {
        int pop;
        public Kiyv(int p)
        {
            pop = p;
        }
        public int Pop
        {
            get { return this.pop; }
        }
    }
}
