﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace France
{
    class Paris
    {
        int pop;
        public Paris(int p)
        {
            pop = p;
        }
        public int Pop
        {
            get { return this.pop; }
        }
    }
}
