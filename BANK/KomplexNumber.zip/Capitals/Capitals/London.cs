﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GB
{
    class London
    {
        int pop;
        public London(int p)
        {
            pop = p;
        }
        public int Pop
        {
            get { return this.pop; }
        }
    }
}
